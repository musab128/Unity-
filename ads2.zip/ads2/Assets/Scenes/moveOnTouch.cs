﻿using UnityEngine;

public class moveOnTouch : MonoBehaviour
{
   
    void Update()
    {
        
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);
            Vector3 v3 = Camera.main.ScreenToWorldPoint(touch.position);
            v3.z = 0f;
            transform.position = v3;
           
        }
    }

}

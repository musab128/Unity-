﻿using UnityEngine;

public class MoveCam : MonoBehaviour
{
    public Vector3 offset;
    public Transform other;

    void LateUpdate()
    {
        Vector3 pos = other.position + offset;
        transform.position = pos;
    }
}

﻿using UnityEngine;

public class ball : MonoBehaviour
{
    public float speed;
    public Joystick joystick;
    captureLand land;

    Rigidbody rb;


    private void Start()
    {
        land = GetComponent<captureLand>();
        rb = GetComponent<Rigidbody>();
    }

    void Update()
    {
        movMent();
        land.NotAfk();
    }


    void movMent()
    {
        float horizontalMove = joystick.Horizontal * speed * Time.deltaTime;
        float verticalMove = joystick.Vertical * speed * Time.deltaTime;

        rb.AddForce(-verticalMove, 0, horizontalMove, ForceMode.VelocityChange);
    }


   
}

﻿using UnityEngine;

public class SpawnSoliders : MonoBehaviour
{

    public GameObject soliders;
    public float timer;
    float countDown;
    public Vector3 range;

    private void Start()
    {
        countDown = timer;
    }


    void Update()
    {
        Vector3 v3Random = transform.position;
        v3Random += Vector3.right * range.x * (Random.value - 0.5f);
        v3Random += Vector3.up * range.y * (Random.value - 0.5f);
        v3Random += Vector3.forward * range.z * (Random.value - 0.5f);


        countDown -= Time.deltaTime;
        if (countDown <= 0)
        {
            Instantiate(soliders, v3Random, transform.rotation);
            countDown = timer;
        }
    }
}

﻿using UnityEngine;

public class MoveSolider : MonoBehaviour
{
    public float speed;
    public float shrinkSpeed;

    public Joystick joystick;
    Rigidbody rb;
    bool AFK = true;

    GameObject player = null;
    captureLand startCapure;

    private void Start()
    {
        rb = GetComponent<Rigidbody>();
        startCapure = GetComponent<captureLand>();
    }


    private void OnCollisionEnter(Collision collision)
    {
    
        if (collision.collider.tag != "Ground" && collision.collider.tag == "ally" && AFK)
        {
            player = collision.gameObject;
            tag = "ally";
        }
        else if (collision.collider.tag != "Ground" && collision.collider.tag == "enemy" && AFK)
        {
            player = collision.gameObject;
            tag = "enemy";
        }


    }


    void Update()
    {
        if (player != null)
        {
            movMent();
            AFK = false;
        }


        if (joystick == null)
        {
            joystick = FindObjectOfType<FixedJoystick>();
        }
    }


    void movMent()
    {
        float horizontalMove = joystick.Horizontal * speed * Time.deltaTime;
        float verticalMove = joystick.Vertical * speed * Time.deltaTime;

        rb.AddForce(-verticalMove, 0, horizontalMove, ForceMode.VelocityChange);


      
        Vector3 v3 = (transform.position - player.transform.position).normalized;
        rb.AddForce(v3 * -shrinkSpeed);

        startCapure.NotAfk();
      
    }
   
}

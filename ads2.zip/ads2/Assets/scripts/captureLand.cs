﻿using UnityEngine;

public class captureLand : MonoBehaviour
{
    public float smoothness;
    public GameObject SmallGreenLand;
    public GameObject SmallRedLand;
    float countDown;
    public Material[] mat;

    Renderer rend;



    private void Start()
    {
        countDown = smoothness;
        rend = GetComponent<Renderer>();
    }


    public void NotAfk()
    {

        Vector3 v3 = transform.position;
        v3.y = 2;

        countDown -= Time.deltaTime;

        if (countDown <= 0)
        {
            if (tag == "enemy")
            {
                Instantiate(SmallRedLand, v3, transform.rotation);
                countDown = smoothness;
                rend.sharedMaterial = mat[0];
            }
            else if(tag == "ally")
            {
                Instantiate(SmallGreenLand, v3, transform.rotation);
                countDown = smoothness;
                rend.sharedMaterial = mat[1];
                    
            }       

        }
    }
}

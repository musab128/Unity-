﻿using System.Collections;
using UnityEngine.Advertisements;
using UnityEngine;
using UnityEngine.SceneManagement;



public class AD : MonoBehaviour , IUnityAdsListener
{
    string placement = "rewardedVideo";

    private void Start()
    {
        Advertisement.AddListener(this);
        Advertisement.Initialize("3529030", true);
    }


    public void ShowAD(string p)
    {
        Advertisement.Show(p);
        Debug.Log("YES It Worked");
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }


    public void OnUnityAdsDidFinish(string placementId, ShowResult showResult)
    {
        if (showResult == ShowResult.Finished)
        {
            Debug.Log("Get +1 coin");
        } 
        else if (showResult == ShowResult.Failed)
        {
            Debug.Log("Opps");
        }
    }

    public void OnUnityAdsReady(string placementId)
    {
    }

    public void OnUnityAdsDidError(string message)
    {
    }

    public void OnUnityAdsDidStart(string placementId)
    {
    }

}
